# Jayson Valderrama
# ID: 001081738
# Data Structures and Algorithms II C950

class Location:

    # Initializes a Location
    def __init__(self, id_, place_name, address, zip_):
        self.id_ = int(id_)
        self.place_name = place_name
        self.address = address
        self.zip_ = zip_
